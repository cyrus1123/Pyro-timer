Primitives
==========

.. automodule:: pyro.primitives
    :members:
    :show-inheritance:
    :member-order: bysource

.. autofunction:: pyro.ops.jit.trace
